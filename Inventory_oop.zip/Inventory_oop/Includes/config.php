<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'jshahdb');
define('DB_USER','jshah');
define('DB_PASSWORD','c80eqc80eq');
?>